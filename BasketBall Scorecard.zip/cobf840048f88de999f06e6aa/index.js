const score = document.getElementById("score");
const score1 = document.getElementById("score1");
const btn  = document.getElementById("btn");
const btn1 = document.getElementById("btn1");
const btn2 = document.getElementById("btn2");
const btn3 = document.getElementById("btn3");
const btn4 = document.getElementById("btn4");
const btn5 = document.getElementById("btn5");
const regame1 = document.getElementById("restart");
const regame2 = document.getElementById("restart1");

let startScore =0;
let startScore1 =0;

btn.addEventListener('click',function(){
    startScore =startScore+1;
    document.getElementById("score").innerText = startScore;
})

btn1.addEventListener('click',function(){
    startScore =startScore+3;
    document.getElementById("score").innerText = startScore;
})

btn2.addEventListener('click',function(){
    startScore =startScore+5;
    document.getElementById("score").innerText = startScore;
})

btn3.addEventListener('click',function(){
    startScore1 =startScore1+1;
    document.getElementById("score1").innerText = startScore1;
})

btn4.addEventListener('click',function(){
    startScore1 =startScore1+3;
    document.getElementById("score1").innerText = startScore1;
})

btn5.addEventListener('click',function(){
    startScore1 =startScore1+5;
    document.getElementById("score1").innerText = startScore1;
})

regame1.addEventListener("click",function(){
    document.getElementById("score").innerText = "00";
})

regame2.addEventListener("click",function(){
    document.getElementById("score1").innerText = "00";
})